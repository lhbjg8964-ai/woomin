package a0826.interfaceShop;
//원가에 할인 적용
public interface Discount { 
    double apply(int price);
    String getName();
    
} 
